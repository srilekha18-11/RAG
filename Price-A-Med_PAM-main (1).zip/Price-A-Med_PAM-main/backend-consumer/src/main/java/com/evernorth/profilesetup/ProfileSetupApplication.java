package com.evernorth.profilesetup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfileSetupApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfileSetupApplication.class, args);
	}

}

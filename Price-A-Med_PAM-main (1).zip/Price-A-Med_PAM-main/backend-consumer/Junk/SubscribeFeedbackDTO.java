//package com.evernorth.profilesetup.kafka.subscribe;
//
//public class SubscribeFeedbackDTO {
//    private String taskID;
//    private boolean status;
//
////    public SubscribeFeedbackDTO(String taskID, boolean status) {
////        this.taskID = taskID;
////        this.status = status;
////    }
//
//    public void setTaskID(String taskID) {
//        this.taskID = taskID;
//    }
//
//    public void setStatus(boolean status) {
//        this.status = status;
//    }
//
//    public String getTaskID() {
//        return taskID;
//    }
//
//    public boolean getStatus() {
//        return status;
//    }
//}
